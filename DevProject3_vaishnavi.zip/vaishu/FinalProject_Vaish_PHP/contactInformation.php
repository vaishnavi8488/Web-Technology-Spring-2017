<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">	
    <!-- OPTIONAL: description -->
    <meta name="description" content="">
    <!-- OPTIONAL: author -->
    <meta name="author" content="">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="apple-touch-icon" href="icon.png" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

	<link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">

   
    <link href="css/main.css" rel="stylesheet">
    
    

    <link href='//fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Raleway:400,300,700' rel='stylesheet' type='text/css'>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96350777-1', 'auto');
  ga('send', 'pageview');

</script>

<script>
function validateEmail(emailField){
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(emailField.value) == false) 
        {
            alert('Invalid Email Address');
            return false;
        }

        return true;
}
</script>
<style>

div.middle{
	margin-left: 20%;
	margin-top: 70px;
	border:1px;
	width: 800px;
	height: 700px;
}
th, td {
    padding: 15px;
}

</style>
<meta charset="UTF-8">

</head>

<body style = "width:100%; height:900px; background-image: url(Background_image.jpg); background-repeat:no-repeat; background-size: 1700px 1000px;">
<div class="middle" align = "center">
	<u><h2>ContactInfo</h2></u>

<form method="POST" name="myForm" action="contactinformation.php">
  <b>Name:</b><br>
  <input type="text" name="name" value="" required="required" placeholder="Enter Name">
  <br><br>
  <b>PhoneNumber:</b><br>
  <input type="text" name="Phone" value="" required="required" placeholder="Enter PhoneNumber">
  <br><br>
  <b>EmailID:</b><br>
  <input type="text" name="EmailID" value="" required="required" placeholder="Enter EmailID" onblur="validateEmail(this);">
  <br><br>
  <b>Message:</b><br>
  <textarea cols="57" rows="6" name="Message" placeholder="Message" required="required"></textarea>
  <br><br>
  <select id="ContactReason" name="ReasonOfContact"></select></br></br>
            <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
          <script >
              var $select = $('#ContactReason');
              $.getJSON('data.json', function(data){
                
                for (var i = 0; i < data['ContactReason'].length; i++) {
                 $select.append('<option id="' + data['ContactReason'][i]['id'] + '">' + data['ContactReason'][i]['name'] + '</option>');
                 }
              });
          </script>
            </br>
  <div class="send">
            <input type="submit" name="send" onsubmit="setTimeout(function () { window.location.reload(); }, 10)">
              </div>
</form> 
</div>

</body>

</html>

<?php

$link= mysqli_connect("localhost","root","","vaishu");
if (isset($_POST['send']))
 {
       $name = $_POST['name'];
       $Phone = ($_POST['Phone']);
       $message = ($_POST['Message']);
       $email = $_POST['EmailID'];
       $roc = $_POST['ReasonOfContact'];

       // Mail Stuff
       $to = "vaishnavi.krishna94@gmail.com";
       $subject1 = "New Form Submitted";
       $txt = "New Contact form has been Submitted";
       $headers = "From: donotreply@fmt.com" ;


       date_default_timezone_set("America/New_York");
       $timestamp = date('Y-m-d G:i:s');
       
       if (isset($_POST['EmailID'])==true && empty($_POST['EmailID'])==false)
        {
        $email=$_POST['EmailID'];
        if (filter_var($email,FILTER_VALIDATE_EMAIL)==true)
         { 
                    
                    $query="INSERT INTO contactform (name,phno,email,message,roc,time_stamp) 
                    values ('$name','$Phone','$email','$message','$roc','$timestamp')";
                    $stmt=$link->prepare($query);
                    if($stmt->execute()==true)
                        {
                             mail($to,$subject1,$txt,$headers);
                             echo "<script>alert(' Submitted Successful')</script>";
                             EXIT();
                             //header('Location:index.php');
                        }
                
        
    }
        else
        {
            echo "<script>alert('Invalid Email Address')</script>";
            die();
        }
    }
}
?>