<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Skills</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<div id="skillSet">
	<br><br><br><br><br><br>
    Skills:
    <ol>
    <li> HTML </li>
    <li> Java Developer </li>
    <li> Support Engineer </li>
    <li> .NET </li>
    <li> SQL </li>
    </ol>
</div>
<script src="app.js"></script>
</body>
</html>