<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Website</title>
    <meta name="author" content="Vaish">
    <meta name="description" content="DevelopmentProject1">
    <meta name="keywords" content="HTML,CSS,JavaScript,Vaish,devproject">
    
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<script src="../js/jquery.js"></script>
<script>
    $(document).ready(
        function(){
            $(".pop1").on('click', function(){
                $(".box").slideDown("slow");
            });

            $(".close").on('click', function(){
                $(".box").slideUp("slow");
        });
    });
</script>
<body>
<ul class="leftnav">
    <li><a class="active" href="#home">HomeScreen</a></li>
    <li><a href="./aboutme.php">AboutMe</a></li>
    <li><a href="./skillSet.php">SkillSet</a></li>
    <li><a  href="./contactInformation.php">ContactInformation</a></li>
</ul>


<div class="imagesContainer">
<img src="vaish.jpg" alt="My Pic" style="width:304px;height:228px;">


</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96369037-1', 'auto');
  ga('send', 'pageview');

</script>

<a href="Resume.pdf" class="button" download style="color: rgb(255,255,255); text-decoration:none;background-color: #bf5050; border: none;
color: white;
   padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-left: 45%;
    margin-top: 4%;">Download Resume</a>

<a style="border:1px width:50px; height:50px;margin-bottom:10px; margin-left:150px" href="https://www.facebook.com/vai.angel79"><img src="facebook.png" height="42" width="42" style="margin-top:10px" alt="facebook" ></a>

<footer>Rights Reserved © Vaishnavi</footer>
<script src="app.js"></script>
</body>

</html>